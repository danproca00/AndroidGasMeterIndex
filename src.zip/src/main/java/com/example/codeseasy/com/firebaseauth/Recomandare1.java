package com.example.codeseasy.com.firebaseauth;
import com.example.codeseasy.com.firebaseauth.R;
import com.example.codeseasy.com.firebaseauth.Recomandare;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Recomandare1 extends Activity {

    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recomandare1);

        backButton = (Button) findViewById(R.id.recomandare);


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Recomandare1.this, Recomandare.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
}

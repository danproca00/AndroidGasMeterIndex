package com.example.codeseasy.com.firebaseauth;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class getRequest {
    private RequestQueue queue;
    private String APIkey = "[API Key]";
    private String brainID = "[Brain id]";
    private char[] illegalChars = {'#', '<', '>', '$', '+', '%', '!', '`', '&',
            '*', '\'', '\"', '|', '{', '}', '/', '\\', ':', '@'};

    public getRequest(Context context) {
        queue = Volley.newRequestQueue(context);
    }

    public interface VolleyResponseListener {
        void onError(String message);

        void onResponse(String reply);
    }

    private String formatMessage(String message) {
        message = message.replace(' ', '-');
        for (char illegalChar : illegalChars) {
            message = message.replace(illegalChar, '-');
        }
        return message;
    }

    public void getResponse(String message, final VolleyResponseListener volleyResponseListener) {
        // Define predefinite questions and answers
        String[] questions = {"Spune mai multe detalii despre aceasta aplicatie",
                "Cum se calculeaza consumul de gaz, exprimat in metri cubi, " +
                        "in functie de indexul citit de la contorul de gaz",
                "Care este formula de calcul a sumei din factura de gaz"};
        String[] answers = {"Bine ați venit la aplicația noastră dedicată citirii și gestionării indexului de gaz! Scopul nostru este de a vă oferi o experiență ușoară și intuitivă pentru a vă ajuta să citiți și să monitorizați consumul de gaz, pentru a vă ajuta să economisiți bani și să mențineți un mediu mai sănătos.\n" +
                "\n" + "Echipa noastră este formată din experți în tehnologie și energie, care împărtășesc o pasiune comună pentru inovare și durabilitate. " +
                "Suntem dedicați să creăm o aplicație care să fie accesibilă și ușor de utilizat pentru toți utilizatorii noștri, indiferent de nivelul lor de experiență în domeniu.\n" + "\n" +
                "Cu ajutorul aplicației noastre, puteți să vă citiți indexul de gaz într-un mod precis și să monitorizați consumul dvs. de gaz în timp real. " +
                "De asemenea, puteți accesa istoricul consumului de gaz și puteți să urmăriți costurile asociate cu consumul de gaz." +
                " Aceste informații vă vor ajuta să vă gestionați mai bine bugetul și să luați decizii informate în ceea ce privește consumul dvs. de gaz.\n" + "\n" +
                "Suntem mândri să oferim o aplicație care să ajute oamenii să economisească bani și să protejeze mediul înconjurător prin reducerea consumului de gaz. " +
                "Vă mulțumim că ați ales aplicația noastră și vă asigurăm că vom continua să dezvoltăm funcționalități noi și utile pentru a vă ajuta să vă atingeți obiectivele privind consumul de energie.",
                "Pentru a calcula consumul de gaz, exprimat în metri cubi, în funcție de indexul citit de la contorul de gaz, poți folosi următoarea formulă:\n" +
                        "\n" + "Consumul (mc) = (Index actual - Index precedent) x Factor de conversie\n" +
                        "\n" + "unde:\n" + "\n" + "Consumul (mc) reprezintă consumul de gaz exprimat în metri cubi\n" +
                        "Index actual reprezintă valoarea citită de la contorul de gaz în prezent\n" +
                        "Index precedent reprezintă valoarea citită de la contorul de gaz în trecut, de obicei la ultima factură\n" +
                        "Factor de conversie este factorul de conversie stabilit de furnizorul de gaz și este folosit pentru a converti unitățile de măsură de la metri cubi la kilowați-oră sau alte unități de măsură\n" +
                        "Pentru a afla valoarea factorului de conversie, poți consulta factura de gaz sau contacta furnizorul tău de gaz.\n" +
                        "\n" + "De exemplu, dacă citirea actuală de la contorul de gaz este de 1256 și citirea precedentă este de 1145, iar factorul de conversie este de 1,1, atunci consumul de gaz, exprimat în metri cubi, ar fi:\n" +
                        "\n" + "(1256 - 1145) x 1,1 = 122 metri cubi\n" +
                        "\n" + "Este important să notezi că formula de mai sus este o metodă simplificată de calcul a consumului de gaz și că poate exista o variație a consumului în funcție de factorii specifici ai furnizorului și ai regiunii.",
                "Formula de calcul al sumei din factura de gaz depinde de mai mulți factori, cum ar fi consumul de gaz, prețul gazului, taxele și impozitele locale, precum și orice alte taxe sau reduceri aplicabile.\n" +
                        "\n" + "În general, factura de gaz poate fi calculată utilizând următoarea formulă simplificată:\n" + "\n" + "S = C x P + T + I\n" +
                        "\n" + "unde:\n" + "\n" + "S = suma totală de plată\n" + "C = consumul de gaz, exprimat în metri cubi sau kilowați-oră\n" +
                        "P = prețul gazului pe metru cub sau kilowați-oră\n" + "T = taxe și impozite locale, cum ar fi taxa de administrare sau impozitul pe proprietate\n" +
                        "I = orice alte taxe sau reduceri aplicabile\n" + "Este important de menționat că prețul gazului poate varia în funcție de mai mulți factori, cum ar fi sezonul, regiunea, furnizorul și alți factori specifici."};

        // Check if the message matches any predefinite question
        int index = -1;
        for (int i = 0; i < questions.length; i++) {
            if (message.equalsIgnoreCase(questions[i])) {
                index = i;
                break;
            }
        }

        // Return corresponding answer or error message
        if (index != -1) {
            volleyResponseListener.onResponse(answers[index]);
        } else {
            volleyResponseListener.onResponse("Pentru a va putea ajuta, va rugam sunati la numarul +40731885747. Multumim!👍");
        }
    }
}

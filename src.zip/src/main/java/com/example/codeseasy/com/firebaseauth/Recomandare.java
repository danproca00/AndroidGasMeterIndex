package com.example.codeseasy.com.firebaseauth;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class Recomandare extends Activity {

    private Button recomandare1Button, recomandare2Button, backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_recomandare);

        recomandare1Button = (Button) findViewById(R.id.recomandare1);
        recomandare2Button = (Button) findViewById(R.id.recomandare2);
        backButton = (Button) findViewById(R.id.button_to_main);

        recomandare1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Recomandare.this, Recomandare1.class);
                startActivity(intent);
            }
        });

        recomandare2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Recomandare.this, Recomandare2.class);
                startActivity(intent);
            }
        });


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Recomandare.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
}

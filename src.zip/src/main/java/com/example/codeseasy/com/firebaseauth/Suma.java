package com.example.codeseasy.com.firebaseauth;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Locale;
import java.util.Objects;






import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Suma extends AppCompatActivity implements ValueEventListener {

    private static final String CHANNEL_ID = "Suma_Channel_ID";

    public TextView resultTextView;

    private static final float MULTIPLIER_1 = 10.5f;
    private static final float MULTIPLIER_2 = 0.61f;
    private static final float MULTIPLIER_3 = 0.19f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suma);

        Button buttonToMain = findViewById(R.id.button_to_main);
        resultTextView = findViewById(R.id.resultTextView);

        buttonToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Suma.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Initialize Firebase Database reference
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.addValueEventListener(this);

        createNotificationChannel();
    }


    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
        float sum = 0;
        float previousIndexValue = 0f;
        boolean firstIteration = true;

        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
            float currentIndexValue = 0f;
            if (snapshot.exists()) {
                currentIndexValue = Float.parseFloat(Objects.requireNonNull(snapshot.getValue()).toString());
            }

            Log.d("SumaActivity", "Valoare curentă: " + currentIndexValue);

            if (!firstIteration) {
                float difference = previousIndexValue - currentIndexValue;
                sum += difference * MULTIPLIER_1 * MULTIPLIER_2 * MULTIPLIER_3;
            } else {
                firstIteration = false;
            }

            previousIndexValue = currentIndexValue;
        }

        final float finalSum = sum;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.d("Suma", "Before setting text: " + resultTextView.getText());

                resultTextView.setText("Suma este de: " + String.format(Locale.getDefault(), "%.2f", finalSum) + " lei");

                Log.d("Suma", "After setting text: " + resultTextView.getText());
            }
        });

        // Trigger the notification after calculation
        triggerNotification();
    }

    @Override
    public void onCancelled(DatabaseError databaseError) {
        // Handle error
    }

    private void triggerNotification() {
        Intent intent = new Intent(this, Suma.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.baseline_notifications_24)
                .setContentTitle("Calcul finalizat")
                .setContentText("Suma a fost calculată. Haide sa vedem cat ai de platit😊")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(1, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Suma Channel";
            String description = "Channel for Suma notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            // Register the channel with the system
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }
}

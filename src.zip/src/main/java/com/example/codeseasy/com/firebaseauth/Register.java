package com.example.codeseasy.com.firebaseauth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Patterns;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class Register extends AppCompatActivity {

    private TextInputEditText emailEt, passET, nameEt;
    private Button signUpBtn;

    private TextView textView;
    private ProgressBar progressBar;
    private TextInputLayout emailLayout, passwordLayout, nameLayout;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        emailEt = findViewById(R.id.emailEt);
        passET = findViewById(R.id.passET);
        nameEt = findViewById(R.id.nameEt);
        signUpBtn = findViewById(R.id.button);
        textView = findViewById(R.id.login);
        progressBar = findViewById(R.id.progressBar);
        emailLayout = findViewById(R.id.emailLayout);
        passwordLayout = findViewById(R.id.passwordLayout);
        nameLayout = findViewById(R.id.nameLayout);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                finish();
            }
        });

        // Adaugă funcționalitatea de logare la apăsarea tastei "Enter" în câmpul de parolă
        passET.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
                    signUpBtn.performClick();
                    return true;
                }
                return false;
            }
        });

        signUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailEt.getText().toString().trim();
                String password = passET.getText().toString().trim();
                String name = nameEt.getText().toString().trim();

                // Verifică dacă adresa de email este validă
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    emailLayout.setError("Please enter a valid email address");
                    emailEt.requestFocus();
                    return;
                } else {
                    emailLayout.setErrorEnabled(false);
                }

                if (TextUtils.isEmpty(password)) {
                    passwordLayout.setError("Please enter your password");
                    passET.requestFocus();
                    return;
                } else if (password.length() < 6) {
                    passwordLayout.setError("Password must be at least 6 characters long");
                    passET.requestFocus();
                    return;
                } else {
                    passwordLayout.setErrorEnabled(false);
                }

                if (TextUtils.isEmpty(name)) {
                    nameLayout.setError("Please enter your name");
                    nameEt.requestFocus();
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);
                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                            .setDisplayName(name)
                                            .build();
                                    user.updateProfile(profileUpdates);
                                    Toast.makeText(getApplicationContext(), "Contul a fost creat cu succes", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getApplicationContext(), Login.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Toast.makeText(Register.this, "Inregistrarea a esuat, va rugam incercati din nou",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

            }
        });
    }
}
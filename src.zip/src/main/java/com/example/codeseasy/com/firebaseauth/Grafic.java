package com.example.codeseasy.com.firebaseauth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;






import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

public class Grafic extends AppCompatActivity {

    private LineChart lineChart;
    private static final String CHANNEL_ID = "grafic_channel";
    private TextView calculatedValueTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafic);

        Button buttonToMain = findViewById(R.id.button_to_main);
        buttonToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Grafic.this, MainActivity.class);
                startActivity(intent);
            }
        });

        calculatedValueTextView = findViewById(R.id.calculatedValue);
        lineChart = findViewById(R.id.LineChart);

        lineChart.setPinchZoom(true);
        lineChart.getDescription().setEnabled(false);

        createNotificationChannel();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<Entry> dataVals = new ArrayList<>();
                float xAxisCounter = 0;
                float previousIndexValue = 0f;
                boolean firstIteration = true;

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    float currentIndexValue = 0f;
                    if (snapshot.exists()) {
                        currentIndexValue = Float.parseFloat(Objects.requireNonNull(snapshot.getValue()).toString());
                    }

                    Log.d("GraficActivity", "Valoare curentă: " + currentIndexValue);

                    if (!firstIteration) {
                        float gasConsumption = calculateGasConsumption(currentIndexValue, previousIndexValue);

                        // Setting the text of the calculatedValueTextView
                        calculatedValueTextView.setText(String.format(Locale.getDefault(), "%.2f", gasConsumption));

                        dataVals.add(new Entry(xAxisCounter, gasConsumption));
                        xAxisCounter++;
                    } else {
                        firstIteration = false;
                    }

                    previousIndexValue = currentIndexValue;
                }

                LineDataSet lineDataSet = new LineDataSet(dataVals, "Consumul de gaze");
                lineDataSet.setLineWidth(2);
                lineDataSet.setColor(Color.BLUE);

                LineData data = new LineData(lineDataSet);
                lineChart.setData(data);
                lineChart.invalidate(); // refresh

                // Trigger the notification after data loaded to the chart
                triggerNotification();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                databaseError.toException().printStackTrace();
            }
        });
    }

    float calculateGasConsumption(float currentIndexValue, float previousIndexValue) {
        float difference = previousIndexValue - currentIndexValue;
        return Math.max(difference, 0);
    }

    private void triggerNotification() {
        Intent intent = new Intent(this, Grafic.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.baseline_notifications_24)
                .setContentTitle("Verifica in aplicatie consumul curent de gaz")
                .setContentText("Haide sa verificam valorile prezente in aplicatie😊")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(1, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Grafic Channel";
            String description = "Channel for Grafic notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }
}

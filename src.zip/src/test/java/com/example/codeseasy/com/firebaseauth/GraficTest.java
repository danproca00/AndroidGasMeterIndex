package com.example.codeseasy.com.firebaseauth;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
public class GraficTest {
    @Test
    public void testCalculateGasConsumption() {
        ActivityController<Grafic> controller = Robolectric.buildActivity(Grafic.class);
        Grafic activity = controller.get();

        // Test 1: Daca indecsii sunt egali, consumul trebuie sa fie 0
        float result = activity.calculateGasConsumption(100f, 100f, 0f, 0f);
        assertEquals(0f, result, 0.0001);

        // Test 2: Daca indicele curent este mai mare decat indicele precedent, consumul ar trebui sa fie diferenta dintre acestea
        result = activity.calculateGasConsumption(200f, 300f, 100f, 200f);
        assertEquals(100f, result, 0.0001);

        // Test 3: Daca indicele curent este mai mic decat cel precedent, consumul ar trebui sa fie 0 (deoarece metoda returneaza maximul dintre diferenta si 0)
        result = activity.calculateGasConsumption(300f, 200f, 200f, 100f);
        assertEquals(0f, result, 0.0001);
    }
}

package com.example.codeseasy.com.firebaseauth;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;


@RunWith(RobolectricTestRunner.class)
public class SumaTest {

    private Suma suma;
    private DataSnapshot mockSnapshot;

    @Before
    public void setUp() {
        suma = new Suma();
        mockSnapshot = mock(DataSnapshot.class);
        suma.resultTextView = mock(TextView.class);

        // Mock the data returned by DataSnapshot
        when(mockSnapshot.child("B2").exists()).thenReturn(true);
        when(mockSnapshot.child("C2").exists()).thenReturn(true);
        when(mockSnapshot.child("B2").getValue(String.class)).thenReturn("10");
        when(mockSnapshot.child("C2").getValue(String.class)).thenReturn("20");
    }

    @Test
    public void onDataChange_withValidData_updatesTextView() {
        suma.onDataChange(mockSnapshot);

        // Verify that resultTextView text has been updated
        assertEquals("Suma este de: 10.0 lei", suma.resultTextView.getText().toString());
    }

}
